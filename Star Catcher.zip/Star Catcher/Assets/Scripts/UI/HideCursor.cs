﻿using UnityEngine;
using System.Collections;

public class HideCursor : MonoBehaviour 
{
	void Start()
	{
		Cursor.visible = false;
	}
}
